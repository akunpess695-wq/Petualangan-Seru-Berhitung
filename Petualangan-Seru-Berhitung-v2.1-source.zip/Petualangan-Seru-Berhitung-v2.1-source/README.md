# Petualangan Seru Berhitung — Living Avatar v2.1

Based on the user's original Android Java source. Retains gameplay, avatar shop, character meshes, questions and progress logic.

## Implemented
- Putra and Putri OpenGL preview uses a lightweight, subtle 30 FPS idle loop (breathing/whole-body sway).
- Animation stops when view is detached, invisible or paused, reducing battery consumption.
- Touch-to-rotate remains available.
- Existing 3D model geometry, hood selection, hair, outfits and school uniforms retained.
- Removes hard-coded debug signing credentials and bundled keystore. Uses Android Gradle's default debug signing.
- Version name 6.23.0.

## Limitations
- The idle animation moves the existing whole-body mesh, not individual joints.
- Facial blinking, facial expressions and separate arm gestures are NOT implemented because the current mesh has no validated facial/arm rig.
- New 3D character models, live 360° preview in all screens, and full UI redesign are NOT included.
- APK has not been compiled or device-tested in this environment.
- A new debug signing key may prevent installing over an older build; uninstalling can erase local app data. Back up before replacing.

## Build
Upload `Petualangan-Seru-Berhitung-v2.1-source.zip` unchanged to GitHub repository root and put `build.yml` in `.github/workflows/build.yml`.
