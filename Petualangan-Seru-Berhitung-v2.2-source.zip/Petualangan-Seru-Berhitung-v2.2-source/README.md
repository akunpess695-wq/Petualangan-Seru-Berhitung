# Petualangan Seru Berhitung v2.2 — Avatar Studio UI Upgrade

This is a **real Android source edit** to the existing Avatar Shop, not a concept mockup.

## Visible changes
- Avatar preview enlarged from 200×200 dp to a 310 dp high gradient studio stage.
- Purple/blue/pink gradient studio frame with rounded corners.
- Live 3D indicator, rotate gesture hint, new headings and customization label.
- More dimensional key/fill lighting in the existing GLES20 renderer.
- Existing Putra/Putri meshes, costumes, player progress, coins and selection remain intact.
- Existing idle body motion is retained.

## Not yet included
- A new rigged 3D character mesh, facial blendshapes/blinking, or independent limb animation.
- Full recreation of the prior AI concept artwork inside the app.
- Tested APK or measured performance; the Android SDK is unavailable here.

## Build
Upload `Petualangan-Seru-Berhitung-v2.2-source.zip` without extracting it to your GitHub repository root. Save the companion workflow as `.github/workflows/build.yml` and run Actions. The workflow extracts the ZIP on the runner.

## Signing warning
Debug signing may differ from your previous APK. Do not uninstall an existing installation with important progress before backing it up.
