# Petualangan Seru Berhitung v2.3 — Character Refinement

## Changes from v2.2
- **Putra already wears long red trousers** in the original procedural 3D geometry; kept for Islamic school uniform compliance.
- Putri retains her long skirt and hijab.
- Smaller eye/iris proportions for a less doll-like face.
- Added actual 3D nose bridge/tip and cheek volumes to both procedural models.
- Added sculpted shoe tongues and laces to both characters.
- Existing costume shop, headwear, bags, coins, school badges and quiz systems preserved.
- Existing 360-degree touch rotation and idle motion retained.

## Scope / honesty
This is a **procedural mesh refinement**, NOT a fully re-rigged photorealistic character or a completely replaced 3D asset. There is no imported GLB/FBX and no skeletal face animation. Visual differences require a fresh APK build; do not expect an identical result to a conceptual image. Model code has been Java-compiled for syntax, but Android APK has not been built or device-tested here.

## Build
Upload `Petualangan-Seru-Berhitung-v2.3-source.zip` to repository root, and put the separate v2.3 workflow at `.github/workflows/build.yml`. No manual extraction. Download the debug APK artifact from GitHub Actions. A debug signing-key change can prevent installation over a previously signed APK; back up progress before uninstalling anything.
